import { FC } from 'react';

import AdapterDateFns from '@mui/lab/AdapterDateFns';
import LocalizationProvider from '@mui/lab/LocalizationProvider';
import { CssBaseline } from '@mui/material';
import { BrowserRouter } from 'react-router-dom';

import ThemeProvider from './theme/ThemeProvider';
import useCookies from 'react-cookie/cjs/useCookies';
import { Router } from './router/Router';

const changeEnv = (env: string) => {
  switch (env) {
    case 'local':
      return 'vbdb2_ui';
    case 'test':
      return 'integra_vbdb2_ui';
    case 'production':
      return 'vbdb2_ui';
    default:
      return '';
  }
};

const App: FC = () => {
  const [cookies] = useCookies();

  return (
    <ThemeProvider>
      <LocalizationProvider dateAdapter={AdapterDateFns}>
        <BrowserRouter basename={changeEnv(cookies['ENV'])}>
          <CssBaseline />
          <Router />
        </BrowserRouter>
      </LocalizationProvider>
    </ThemeProvider>
  );
};
export default App;
