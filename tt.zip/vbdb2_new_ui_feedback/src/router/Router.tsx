import { Suspense, lazy } from 'react';
import { Navigate } from 'react-router-dom';
import { RouteObject, useRoutes } from 'react-router';

import SidebarLayout from 'src/layouts/SidebarLayout';
import BaseLayout from 'src/layouts/BaseLayout';
import SuspenseLoader from 'src/components/SuspenseLoader';
import Overview from 'src/content/overview';
import DashboardGrid from 'src/content/dashboards/DashboardGrid';
import Feedback from 'src/content/others/Feedback';
import Maintenance from 'src/content/management/Maintenance';

// const Loader = (Component) => (props) =>
//   (
//     <Suspense fallback={<SuspenseLoader />}>
//       <Component {...props} />
//     </Suspense>
//   );

// const Overview = Loader(lazy(() => import('src/content/overview')));

// // Dashboards

// const DashboardGrid = Loader(
//   lazy(() => import('src/content/dashboards/DashboardGrid'))
// );

// // Feedback
// const Feedback = Loader(lazy(() => import('src/content/others/Feedback')));

// // Maintennance
// const Maintenance = Loader(
//   lazy(() => import('src/content/management/Maintenance'))
// );

const routes: RouteObject[] = [
  {
    path: '',
    element: <BaseLayout />,
    children: [
      {
        path: `/`,
        element: <Overview />
      },
      {
        path: `overview`,
        element: <Navigate to="/" replace />
      }
    ]
  },
  {
    path: 'dashboards',
    element: <SidebarLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="frame" replace />
      },
      {
        path: 'frame',
        element: <DashboardGrid groupId="F" />
      },
      {
        path: 'engine',
        element: <DashboardGrid groupId="E" />
      },
      {
        path: 'research',
        element: <DashboardGrid groupId="A" />
      },
      {
        path: 'others',
        element: <DashboardGrid groupId="C" />
      }
    ]
  },
  {
    path: 'others',
    element: <SidebarLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="feedback" replace />
      },
      {
        path: 'feedback',
        element: <Feedback />
      }
    ]
  },
  {
    path: 'management',
    element: <BaseLayout />,
    children: [
      {
        path: '',
        element: <Navigate to="maintenance" replace />
      },
      {
        path: 'maintenance',
        element: <Maintenance />
      }
    ]
  },
  {
    path: '*',
    element: <Maintenance />
  }
];

export const Router = () => {
  const content = useRoutes(routes);
  return <>{content}</>;
};
