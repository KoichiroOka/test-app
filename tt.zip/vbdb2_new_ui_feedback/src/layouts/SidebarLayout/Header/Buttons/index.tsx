import { FC } from 'react';
import { Box } from '@mui/material';

import HeaderSearch from './Search';

const HeaderButtons: FC = () => {
  return (
    <Box sx={{ mr: 1 }}>
      <HeaderSearch />
    </Box>
  );
};

export default HeaderButtons;
