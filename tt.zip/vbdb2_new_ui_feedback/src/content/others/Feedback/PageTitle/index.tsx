import { FC, useState } from 'react';
import PropTypes from 'prop-types';
import { Typography, Button, Grid, useTheme, Drawer, Box } from '@mui/material';
import AddTwoToneIcon from '@mui/icons-material/AddTwoTone';

import NewFeedback from './NewFeedback';

interface PageTitleProps {
  heading?: string;
  subHeading?: string;
  docs?: string;
}

const PageTitle: FC<PageTitleProps> = ({
  heading = '',
  subHeading = '',
  docs = '',
  ...rest
}) => {
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  return (
    <Grid
      container
      justifyContent="space-between"
      alignItems="center"
      {...rest}
    >
      <Grid item>
        <Typography variant="h3" component="h3" gutterBottom>
          {heading}
        </Typography>
        <Typography variant="subtitle2">{subHeading}</Typography>
      </Grid>
      <Grid item>
        <Button
          href={docs}
          target="_blank"
          rel="noopener noreferrer"
          sx={{ mt: { xs: 2, md: 0 } }}
          startIcon={<AddTwoToneIcon fontSize="small" />}
          variant="contained"
          onClick={handleDrawerToggle}
        >
          新規作成
        </Button>
        <Drawer
          sx={{
            boxShadow: `${theme.sidebar.boxShadow}`
          }}
          variant="temporary"
          anchor={theme.direction === 'rtl' ? 'bottom' : 'top'}
          open={mobileOpen}
          onClose={handleDrawerToggle}
          elevation={9}
        >
          <Box
            sx={{
              minWidth: 360
            }}
            p={2}
          >
            <NewFeedback onClose={handleDrawerToggle} />
          </Box>
        </Drawer>
      </Grid>
    </Grid>
  );
};

PageTitle.propTypes = {
  heading: PropTypes.string,
  subHeading: PropTypes.string,
  docs: PropTypes.string
};

export default PageTitle;
