import { FC, Fragment } from 'react';
import {
  Box,
  Card,
  CardContent,
  Divider,
  Grid,
  Typography
} from '@mui/material';

import Text from 'src/components/Text';
import { FeedbackForm } from 'src/types/FeedbackForm';

const changeJa = (tracker: string) => {
  switch (tracker) {
    case '1':
      return '不具合';
    case '2':
      return '要望';
    case '3':
      return 'その他(サポート)';
    default:
      return '存在しないトラッカー';
  }
};

const Review: FC<FeedbackForm> = ({
  userId,
  tracker,
  subject,
  description,
  postFileData
}) => {
  return (
    <Fragment>
      <Card>
        <Box
          p={2}
          display="flex"
          alignItems="center"
          justifyContent="space-between"
        >
          <Typography variant="h5" gutterBottom>
            {subject}
          </Typography>
        </Box>
        <Divider />
        <CardContent sx={{ p: 2 }}>
          <Typography variant="subtitle2">
            <Grid container spacing={0}>
              <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                <Box pr={3} pb={2}>
                  職番:
                </Box>
              </Grid>
              <Grid item xs={12} sm={8} md={9}>
                <Text color="black">
                  <b>{userId}</b>
                </Text>
              </Grid>
              <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                <Box pr={3} pb={2}>
                  種類:
                </Box>
              </Grid>
              <Grid item xs={12} sm={8} md={9}>
                <Text color="black">
                  <b>{changeJa(tracker)}</b>
                </Text>
              </Grid>
              <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                <Box pr={3} pb={2}>
                  内容:
                </Box>
              </Grid>
              <Grid item xs={12} sm={8} md={9}>
                <Box sx={{ maxWidth: { xs: 'auto', sm: 300 } }}>
                  <Text color="black">
                    <b>{description}</b>
                  </Text>
                </Box>
              </Grid>

              <Grid item xs={12} sm={4} md={3} textAlign={{ sm: 'right' }}>
                <Box pr={3} pb={2}>
                  添付ファイル:
                </Box>
              </Grid>
              <Grid item xs={12} sm={8} md={9}>
                <Box sx={{ maxWidth: { xs: 'auto', sm: 300 } }}>
                  {postFileData ? (
                    <Text color="black">
                      <b>{postFileData.name}</b>
                    </Text>
                  ) : (
                    <Text color="black">-</Text>
                  )}
                </Box>
              </Grid>
            </Grid>
          </Typography>
        </CardContent>
      </Card>
    </Fragment>
  );
};

export default Review;
