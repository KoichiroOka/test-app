import { FC, Fragment, useState } from 'react';
import {
  Box,
  Button,
  CssBaseline,
  Container,
  IconButton,
  Paper,
  Stepper,
  Step,
  StepLabel,
  Tooltip,
  Typography
} from '@mui/material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CloseIcon from '@mui/icons-material/Close';

import { useApiPostIssues } from 'src/hooks/redmine/useApiPostIssues';
import { useApiPostAttachments } from 'src/hooks/redmine/useApiPostAttachments';
import { FeedbackForm } from 'src/types/FeedbackForm';
import Form from './Form';
import Review from './Review';

const theme = createTheme();

const initFormValue: FeedbackForm = {
  userId: 'J0',
  tracker: '1',
  subject: '',
  description: ''
};

type Props = {
  onClose: () => void;
};

const NewFeedback: FC<Props> = ({ onClose }) => {
  const [userIdErr, setUserIdErr] = useState('');
  const [subjectErr, setSubjectErr] = useState('');

  const [postFileData, setPostFileData] = useState<File | null>(null);

  const { token, uploadFile } = useApiPostAttachments();

  const changeUploadFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPostFileData(e.target.files[0]);
      changeFormValues({ ...formValues, postFileData: e.target.files[0] });
    } // File
  };

  const [formValues, setFormValues] = useState<FeedbackForm>(initFormValue);

  const changeFormValues = (props: FeedbackForm) => {
    setFormValues(props);
  };

  const { postFeedbackForms } = useApiPostIssues();

  const [activeStep, setActiveStep] = useState(0);

  const handleNext = (e) => {
    e.preventDefault();
    setUserIdErr('');
    setSubjectErr('');
    let error = false;
    const regexp = /^J0\d{6}$/;
    if (!regexp.test(formValues.userId)) {
      error = true;
      setUserIdErr('有効な職番を入力してください');
    }
    if (formValues.subject === '') {
      error = true;
      setSubjectErr('題目を入力してください');
    }
    if (error) return;
    setActiveStep(activeStep + 1);
    if (activeStep === 0) {
      if (formValues.postFileData) {
        uploadFile(formValues.postFileData);
      }
    }
    if (activeStep === 1) {
      postFeedbackForms(formValues, token);
    }
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };

  const steps = ['Form', 'Review'];

  const getStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Form
            changeFormValues={changeFormValues}
            formValues={formValues}
            userIdErr={userIdErr}
            subjectErr={subjectErr}
            changeUploadFile={changeUploadFile}
            postFileData={postFileData}
          />
        );
      case 1:
        return (
          <Review
            userId={formValues.userId}
            tracker={formValues.tracker}
            subject={formValues.subject}
            description={formValues.description}
            postFileData={postFileData}
          />
        );
      default:
        throw new Error('Unknown step');
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container component="main" maxWidth="sm" sx={{ mb: 4 }}>
        <Paper
          variant="outlined"
          sx={{ my: { xs: 3, md: 6 }, p: { xs: 2, md: 3 } }}
        >
          <Tooltip placement="top-end" title="Close">
            <IconButton color="primary" onClick={onClose}>
              <CloseIcon />
            </IconButton>
          </Tooltip>
          <Typography component="h1" variant="h4" align="center">
            新規作成
          </Typography>
          <Stepper activeStep={activeStep} sx={{ pt: 3, pb: 5 }}>
            {steps.map((label) => (
              <Step key={label}>
                <StepLabel>{label}</StepLabel>
              </Step>
            ))}
          </Stepper>
          {activeStep === steps.length ? (
            <Fragment>
              <Typography variant="h5" gutterBottom>
                フィードバックありがとうございます。
              </Typography>
              <Typography variant="subtitle1">
                新規リストより確認してください。
              </Typography>
            </Fragment>
          ) : (
            <Fragment>
              {getStepContent(activeStep)}
              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                {activeStep !== 0 && (
                  <Button onClick={handleBack} sx={{ mt: 3, ml: 1 }}>
                    Back
                  </Button>
                )}
                <Button
                  variant="contained"
                  onClick={handleNext}
                  sx={{ mt: 3, ml: 1 }}
                >
                  {activeStep === steps.length - 1 ? 'Submit' : 'Next'}
                </Button>
              </Box>
            </Fragment>
          )}
        </Paper>
      </Container>
    </ThemeProvider>
  );
};

export default NewFeedback;
