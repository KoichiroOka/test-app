import { FC, useCallback, useEffect, useState } from 'react';
import {
  Box,
  Card,
  CardHeader,
  ListItemText,
  List,
  ListItem,
  Divider,
  ListItemAvatar,
  Avatar,
  styled,
  Grid,
  CircularProgress,
  ListItemButton
} from '@mui/material';
import LightbulbIcon from '@mui/icons-material/Lightbulb';
import AutorenewIcon from '@mui/icons-material/Autorenew';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';

import Text from 'src/components/Text';
import { useFeedback } from 'src/contexts/FeedbackProvider';
import { useApiListIssues } from 'src/hooks/redmine/useApiListIssues';
import { useSelectFeedbackForm } from 'src/hooks/useSelectFeedbackForm';
import FeedbackDetailModal from './FeedbackDetailModal';

const AvatarWrapperError = styled(Avatar)(
  ({ theme }) => `
      background-color: ${theme.colors.error.lighter};
      color:  ${theme.colors.error.main};
`
);

const AvatarWrapperSuccess = styled(Avatar)(
  ({ theme }) => `
      background-color: ${theme.colors.success.lighter};
      color:  ${theme.colors.success.main};
`
);

const AvatarWrapperWarning = styled(Avatar)(
  ({ theme }) => `
      background-color: ${theme.colors.warning.lighter};
      color:  ${theme.colors.warning.main};
`
);

const FeedbackList: FC = () => {
  const { getFeedbackForms, loading } = useApiListIssues();
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const { feedbackForms } = useFeedback();

  const { onSelectFeedbackForm, selectedFeedbackForm } =
    useSelectFeedbackForm();
  const onClickForm = useCallback(
    (id: number) => {
      onSelectFeedbackForm({ id, feedbackForms, handleOpen });
    },
    [feedbackForms, onSelectFeedbackForm, setOpen]
  );

  useEffect(() => getFeedbackForms(), [getFeedbackForms]);

  return (
    <>
      <Grid
        container
        direction="row"
        justifyContent="center"
        alignItems="stretch"
        spacing={4}
      >
        <Grid item xs={12}>
          {loading ? (
            <Box
              component="div"
              sx={{
                display: 'inline',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <CircularProgress
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              />
            </Box>
          ) : (
            <Card>
              <CardHeader title="新規" />
              <Divider />
              <List disablePadding>
                {feedbackForms.map((obj) => {
                  if (obj.status == '1')
                    return (
                      <ListItem
                        divider
                        sx={{
                          py: 2
                        }}
                        key={obj.id}
                      >
                        <ListItemButton onClick={() => onClickForm(obj.id)}>
                          <ListItemAvatar>
                            <AvatarWrapperError>
                              <LightbulbIcon />
                            </AvatarWrapperError>
                          </ListItemAvatar>
                          <ListItemText
                            primary={
                              <>
                                <Text color="secondary">{`[#${obj.id}]`}</Text>
                                <Text color="black">{`${obj.subject}`}</Text>
                              </>
                            }
                            primaryTypographyProps={{
                              variant: 'body1',
                              fontWeight: 'bold',
                              color: 'textPrimary',
                              gutterBottom: true,
                              noWrap: true
                            }}
                            secondary={
                              <Text color="error">{obj.startDate}</Text>
                            }
                            secondaryTypographyProps={{
                              variant: 'body2',
                              noWrap: true
                            }}
                          />
                        </ListItemButton>
                      </ListItem>
                    );
                })}
              </List>
            </Card>
          )}
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            {loading ? (
              <Box
                component="div"
                sx={{
                  display: 'inline',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <CircularProgress
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                />
              </Box>
            ) : (
              <Card>
                <CardHeader title="進行中" />
                <Divider />
                <List disablePadding>
                  {feedbackForms.map((obj) => {
                    if (obj.status == '2')
                      return (
                        <ListItem
                          divider
                          sx={{
                            py: 2
                          }}
                          key={obj.id}
                        >
                          <ListItemButton onClick={() => onClickForm(obj.id)}>
                            <ListItemAvatar>
                              <AvatarWrapperSuccess>
                                <AutorenewIcon />
                              </AvatarWrapperSuccess>
                            </ListItemAvatar>
                            <ListItemText
                              primary={
                                <>
                                  <Text color="secondary">{`[#${obj.id}]`}</Text>
                                  <Text color="black">{`${obj.subject}`}</Text>
                                </>
                              }
                              primaryTypographyProps={{
                                variant: 'body1',
                                fontWeight: 'bold',
                                color: 'textPrimary',
                                gutterBottom: true,
                                noWrap: true
                              }}
                              secondary={
                                <Text color="success">{obj.startDate}</Text>
                              }
                              secondaryTypographyProps={{
                                variant: 'body2',
                                noWrap: true
                              }}
                            />
                          </ListItemButton>
                        </ListItem>
                      );
                  })}
                </List>
              </Card>
            )}
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <Grid item xs={12}>
            {loading ? (
              <Box
                component="div"
                sx={{
                  display: 'inline',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <CircularProgress
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                />
              </Box>
            ) : (
              <Card>
                <CardHeader title="終了" />
                <Divider />
                <List disablePadding>
                  {feedbackForms.map((obj) => {
                    if (obj.status == '5')
                      return (
                        <ListItem
                          divider
                          sx={{
                            py: 2
                          }}
                          key={obj.id}
                        >
                          <ListItemButton onClick={() => onClickForm(obj.id)}>
                            <ListItemAvatar>
                              <AvatarWrapperWarning>
                                <CheckCircleIcon />
                              </AvatarWrapperWarning>
                            </ListItemAvatar>
                            <ListItemText
                              primary={
                                <>
                                  <Text color="secondary">{`[#${obj.id}]`}</Text>
                                  <Text color="black">{`${obj.subject}`}</Text>
                                </>
                              }
                              primaryTypographyProps={{
                                variant: 'body1',
                                fontWeight: 'bold',
                                color: 'textPrimary',
                                gutterBottom: true,
                                noWrap: true
                              }}
                              secondary={
                                <Text color="warning">{obj.startDate}</Text>
                              }
                              secondaryTypographyProps={{
                                variant: 'body2',
                                noWrap: true
                              }}
                            />
                          </ListItemButton>
                        </ListItem>
                      );
                  })}
                </List>
              </Card>
            )}
          </Grid>
        </Grid>
      </Grid>
      <FeedbackDetailModal
        isOpen={open}
        onClose={handleClose}
        feedbackform={selectedFeedbackForm}
      />
    </>
  );
};

export default FeedbackList;
