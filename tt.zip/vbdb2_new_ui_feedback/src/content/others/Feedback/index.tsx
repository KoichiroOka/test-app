import { FC } from 'react';
import { Helmet } from 'react-helmet-async';
import { Container } from '@mui/material';

import Footer from 'src/components/Footer';
import PageTitleWrapper from 'src/components/PageTitleWrapper';
import { FeedbackProvider } from 'src/contexts/FeedbackProvider';
import FeedbackList from './FeedbackList';
import PageTitle from './PageTitle';

const Feedback: FC = () => {
  return (
    <FeedbackProvider>
      <Helmet>
        <title>Forms - Components</title>
      </Helmet>
      <PageTitleWrapper>
        <PageTitle
          heading="ユーザの声"
          subHeading="新UIのフィードバックをお願いします"
        />
      </PageTitleWrapper>
      <Container maxWidth="lg">
        <FeedbackList />
      </Container>
      <Footer />
    </FeedbackProvider>
  );
};

export default Feedback;
