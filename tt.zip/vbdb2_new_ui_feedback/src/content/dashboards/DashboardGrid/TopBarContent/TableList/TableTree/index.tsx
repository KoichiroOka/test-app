import { FC, useCallback, useLayoutEffect } from 'react';
import { styled } from '@mui/material/styles';
import { Box, CircularProgress, Typography } from '@mui/material';
import TreeView from '@mui/lab/TreeView';
import TreeItem, { TreeItemProps, treeItemClasses } from '@mui/lab/TreeItem';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowRightIcon from '@mui/icons-material/ArrowRight';
import FolderIcon from '@mui/icons-material/Folder';
import TableChartIcon from '@mui/icons-material/TableChart';

import { useApiTableList } from 'src/hooks/vbdb2/useApiTableList';
import { useGroup } from 'src/contexts/GroupProvider';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import { GridList } from 'src/types/TableTree';

declare module 'react' {
  interface CSSProperties {
    '--tree-view-color'?: string;
    '--tree-view-bg-color'?: string;
  }
}

type StyledTreeItemProps = TreeItemProps & {
  labelText: string;
  isDataGrid: boolean;
};

const StyledTreeItemRoot = styled(TreeItem)(({ theme }) => ({
  color: theme.palette.text.secondary,
  [`& .${treeItemClasses.content}`]: {
    color: theme.palette.text.secondary,
    borderTopRightRadius: theme.spacing(2),
    borderBottomRightRadius: theme.spacing(2),
    paddingRight: theme.spacing(1),
    fontWeight: theme.typography.fontWeightMedium,
    '&.Mui-expanded': {
      fontWeight: theme.typography.fontWeightRegular
    },
    '&:hover': {
      backgroundColor: theme.palette.action.hover
    },
    '&.Mui-focused, &.Mui-selected, &.Mui-selected.Mui-focused': {
      backgroundColor: `var(--tree-view-bg-color, ${theme.palette.action.selected})`,
      color: 'var(--tree-view-color)'
    },
    [`& .${treeItemClasses.label}`]: {
      fontWeight: 'inherit',
      color: 'inherit'
    }
  },
  [`& .${treeItemClasses.group}`]: {
    marginLeft: 10,
    [`& .${treeItemClasses.content}`]: {
      paddingLeft: theme.spacing(2)
    }
  }
}));

const StyledTreeItem: FC<StyledTreeItemProps> = ({
  labelText,
  isDataGrid,
  nodeId,
  ...other
}) => {
  const { setTargetTable } = useTargetTable();
  const { groupMobileOpen, setGroupMobileOpen } = useGroup();

  const onSelectTable = useCallback((id: string, name: string) => {
    setTargetTable({ table_id: id, name: name, type: 'T', ancestors: [] });
    setGroupMobileOpen(!groupMobileOpen);
  }, []);

  return (
    <StyledTreeItemRoot
      nodeId={nodeId}
      label={
        <Box
          sx={{ display: 'flex', alignItems: 'center', p: 0.5, pr: 0 }}
          onClick={() => {
            if (isDataGrid) {
              onSelectTable(nodeId, labelText);
            }
          }}
        >
          <Box
            component={isDataGrid ? TableChartIcon : FolderIcon}
            color="inherit"
            sx={{ mr: 1 }}
          />
          <Typography
            variant="body2"
            sx={{ fontWeight: 'inherit', flexGrow: 1 }}
          >
            {labelText}
          </Typography>
        </Box>
      }
      style={{
        '--tree-view-color': isDataGrid ? '#1a73e8' : '',
        '--tree-view-bg-color': isDataGrid ? '#e8f0fe' : ''
      }}
      {...other}
    />
  );
};

const renderTree = (lv1Obj: GridList) => (
  <StyledTreeItem
    key={lv1Obj.id}
    nodeId={lv1Obj.id}
    labelText={lv1Obj.name}
    isDataGrid={lv1Obj.isDataGrid}
  >
    {lv1Obj.children?.map(renderTree)}
  </StyledTreeItem>
);

const TableTree: FC = () => {
  const { getGridList, gridList, loading } = useApiTableList();
  const { groupId } = useGroup();
  const { targetTable } = useTargetTable();

  useLayoutEffect(() => {
    getGridList(groupId);
  }, [getGridList]);

  return (
    <>
      {loading ? (
        <Box
          component="div"
          sx={{
            display: 'inline',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <CircularProgress
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          />
        </Box>
      ) : (
        <TreeView
          aria-label="list"
          defaultCollapseIcon={<ArrowDropDownIcon />}
          defaultExpandIcon={<ArrowRightIcon />}
          defaultEndIcon={<div style={{ width: 24 }} />}
          defaultExpanded={targetTable.ancestors}
          sx={{ flexGrow: 1, maxWidth: 400, overflowY: 'auto' }}
        >
          {gridList.data?.map(renderTree)}
        </TreeView>
      )}
    </>
  );
};

export default TableTree;
