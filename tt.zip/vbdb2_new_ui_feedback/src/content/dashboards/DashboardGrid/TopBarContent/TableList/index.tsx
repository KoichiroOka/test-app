import { FC } from 'react';
import { Box, Button, Divider, Drawer, useTheme } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';

import { useGroup } from 'src/contexts/GroupProvider';
import TableTree from './TableTree';

type Props = {
  color: 'primary' | 'info' | 'success' | 'secondary';
};

const TableList: FC<Props> = (props) => {
  const { color } = props;
  const theme = useTheme();
  const { groupMobileOpen, setGroupMobileOpen } = useGroup();

  const handleDrawerToggle = () => {
    setGroupMobileOpen(!groupMobileOpen);
  };

  return (
    <>
      <Button
        startIcon={<HomeIcon />}
        variant="contained"
        onClick={handleDrawerToggle}
        color={color}
      >
        Table List
      </Button>
      <Drawer
        sx={{
          boxShadow: `${theme.sidebar.boxShadow}`
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'right' : 'left'}
        open={groupMobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <Divider
            sx={{
              my: 3
            }}
          />
          <TableTree />
        </Box>
      </Drawer>
    </>
  );
};

export default TableList;
