import { FC, MutableRefObject, useCallback } from 'react';
import { Box, Typography, styled } from '@mui/material';
import { AgGridReact } from 'ag-grid-react';

import { useTargetTable } from 'src/contexts/DataGridProvider';
import { useGroup } from 'src/contexts/GroupProvider';
import TableList from './TableList';
import TableOperator from './TableOperator';

const RootWrapper = styled(Box)(
  ({ theme }) => `
        @media (min-width: ${theme.breakpoints.values.md}px) {
          display: flex;
          align-items: center;
          justify-content: space-between;
      }
`
);

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
};

const getColor = (groupId: string) => {
  switch (groupId) {
    case 'E':
      return 'info';
    case 'A':
      return 'success';
    case 'C':
      return 'secondary';
    default:
      return 'primary';
  }
};

const TopBarContent: FC<Props> = (props) => {
  const { gridRef } = props;

  const { targetTable } = useTargetTable();
  const { groupId } = useGroup();

  return (
    <RootWrapper>
      <Box ml={1}>
        <TableList color={getColor(groupId)} />
      </Box>
      <Box sx={{ mx: 2 }}>
        <Typography
          variant="h3"
          component="h3"
          gutterBottom
          sx={{ fontWeight: 'inherit', flexGrow: 1 }}
        >
          {targetTable.name}
        </Typography>
      </Box>
      <Box ml={1} sx={{ mx: 2 }}>
        <TableOperator gridRef={gridRef} color={getColor(groupId)} />
      </Box>
    </RootWrapper>
  );
};

export default TopBarContent;
