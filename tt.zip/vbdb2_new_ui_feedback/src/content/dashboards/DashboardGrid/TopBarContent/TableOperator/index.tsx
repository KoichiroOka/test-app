import { FC, MutableRefObject, useState } from 'react';

import { Box, Divider, Drawer, SpeedDial, useTheme } from '@mui/material';
import SpeedDialIcon from '@mui/material/SpeedDialIcon';
import SpeedDialAction from '@mui/material/SpeedDialAction';
import FileDownloadTwoToneIcon from '@mui/icons-material/FileDownloadTwoTone';
import ViewColumnIcon from '@mui/icons-material/ViewColumn';
import FilterListOffIcon from '@mui/icons-material/FilterListOff';

import { AgGridReact } from 'ag-grid-react';
import CheckBoxTree from '../ColumnShowList/CheckBoxTree';
import { useTargetTable } from 'src/contexts/DataGridProvider';

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
  color: 'primary' | 'info' | 'success' | 'secondary';
};

const TableOperator: FC<Props> = (props) => {
  const { targetTable } = useTargetTable();
  const { gridRef, color } = props;

  const theme = useTheme();

  const [mobileOpen, setMobileOpen] = useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const getParams = () => {
    return {
      fileName: targetTable.name,
      onlySelected: true
    };
  };

  const actions = [
    {
      icon: <ViewColumnIcon />,
      name: 'Column Show/Hide',
      onclick: () => {
        setMobileOpen(!mobileOpen);
      }
    },
    {
      icon: <FileDownloadTwoToneIcon />,
      name: 'Export',
      onclick: () => {
        gridRef.current!.api.exportDataAsCsv(getParams());
      }
    },
    {
      icon: <FilterListOffIcon />,
      name: 'Filter State Reset',
      onclick: () => {
        gridRef.current!.api.setFilterModel(null);
      }
    }
  ];
  return (
    <>
      <Box sx={{ transform: 'translateZ(0px)', flexGrow: 1 }}>
        <SpeedDial
          ariaLabel="Table Operator"
          sx={{ left: 16 }}
          icon={<SpeedDialIcon color="info" />}
          direction="right"
          FabProps={{
            sx: {
              bgcolor: `${color}.main`,
              '&:hover': {
                bgcolor: `${color}.main`
              }
            }
          }}
        >
          {actions.map((action) => (
            <SpeedDialAction
              key={action.name}
              icon={action.icon}
              tooltipTitle={action.name}
              onClick={action.onclick}
            />
          ))}
        </SpeedDial>
      </Box>
      <Drawer
        sx={{
          display: { xs: 'none', md: 'flex' }
        }}
        variant="temporary"
        anchor={theme.direction === 'rtl' ? 'left' : 'right'}
        open={mobileOpen}
        onClose={handleDrawerToggle}
        elevation={9}
      >
        <Box
          sx={{
            minWidth: 360
          }}
          p={2}
        >
          <Divider
            sx={{
              my: 3
            }}
          />
          <CheckBoxTree />
        </Box>
      </Drawer>
    </>
  );
};

export default TableOperator;
