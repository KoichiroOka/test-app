import { FC, useRef } from 'react';
import { Box, styled } from '@mui/material';
import { Helmet } from 'react-helmet-async';

import Footer from 'src/components/Footer';
import { GroupProvider } from 'src/contexts/GroupProvider';
import { DataGridProvider } from 'src/contexts/DataGridProvider';
import TopBarContent from './TopBarContent';
import AgGrid from './AgGrid';
import { AgGridReact } from 'ag-grid-react';

const RootWrapper = styled(Box)(
  ({ theme }) => `
       height: calc(100vh - ${theme.header.height});
       display: flex;
`
);

const GridWindow = styled(Box)(
  () => `
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        flex: 1;
`
);

const GridTopBar = styled(Box)(
  ({ theme }) => `
        background: ${theme.colors.alpha.white[100]};
        border-bottom: ${theme.colors.alpha.black[10]} solid 1px;
        padding: ${theme.spacing(2)};
        align-items: center;
`
);

type Props = {
  groupId: 'E' | 'F' | 'A' | 'C';
};

const DashboardGrid: FC<Props> = ({ groupId = 'F' }) => {
  const gridRef = useRef<AgGridReact>(null);
  return (
    <>
      <Helmet>
        <title>Dashboard Grid</title>
      </Helmet>
      <RootWrapper className="Mui-FixedWrapper">
        <GroupProvider groupId={groupId}>
          <DataGridProvider groupId={groupId}>
            <GridWindow>
              <GridTopBar
                sx={{
                  display: { xs: 'flex', xl: 'inline-block' }
                }}
              >
                <TopBarContent gridRef={gridRef} />
              </GridTopBar>
              <Box flex={1}>
                <AgGrid gridRef={gridRef} />
              </Box>
              <Footer />
            </GridWindow>
          </DataGridProvider>
        </GroupProvider>
      </RootWrapper>
    </>
  );
};

export default DashboardGrid;
