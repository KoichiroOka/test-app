import {
  memo,
  MutableRefObject,
  useCallback,
  useLayoutEffect,
  useMemo
} from 'react';
import {
  CheckboxSelectionCallbackParams,
  ColDef,
  RowClassParams,
  RowStyle,
  HeaderCheckboxSelectionCallbackParams
} from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { AgGridReact } from 'ag-grid-react';
import { Box, CircularProgress } from '@mui/material';
import styled from '@emotion/styled';

import { useApiTableRowData } from 'src/hooks/vbdb2/useApiTableRowData';
import { useApiTableColumnDef } from 'src/hooks/vbdb2/useApiTableColumnDef';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import CustomHeader from './CustomHeader';

import './styles.css';

type Props = {
  gridRef: MutableRefObject<AgGridReact<any>>;
};

function isFirstColumn(
  params:
    | CheckboxSelectionCallbackParams
    | HeaderCheckboxSelectionCallbackParams
) {
  var displayedColumns = params.columnApi.getAllDisplayedColumns();
  var thisIsFirstColumn = displayedColumns[0] === params.column;
  return thisIsFirstColumn;
}

const AgGrid = memo((props: Props) => {
  const { agColumnDef, targetTable, pinnedUnitData } = useTargetTable();
  const { getAgColumnDef } = useApiTableColumnDef();
  const { agRowData, getAgRowData, loading } = useApiTableRowData();

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      columnGroupShow: 'open',
      sortable: true,
      resizable: true,
      filter: true,
      headerCheckboxSelection: isFirstColumn,
      checkboxSelection: isFirstColumn
    };
  }, []);

  const getRowStyle = useCallback(
    (params: RowClassParams): RowStyle | undefined => {
      if (params.node.rowPinned) {
        return { 'font-weight': 'bold', color: 'Navy' };
      }
    },
    []
  );

  useLayoutEffect(() => {
    getAgColumnDef(targetTable.table_id);
    getAgRowData(targetTable.table_id);
  }, [targetTable.table_id]);

  const ProgressBox = styled(Box)(
    () => `
        height: 100%;
        display: flex;
        flex: 1;
        overflow: auto;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    `
  );

  const GridBox = styled(Box)(
    () => `
        height: 100%;
        `
  );

  const components = useMemo<{
    [p: string]: any;
  }>(() => {
    return {
      agColumnHeader: CustomHeader
    };
  }, []);

  return (
    <GridBox className="ag-theme-alpine" p={2}>
      {loading ? (
        <ProgressBox>
          <CircularProgress />
        </ProgressBox>
      ) : (
        <AgGridReact
          ref={props.gridRef}
          rowData={agRowData}
          columnDefs={agColumnDef}
          defaultColDef={defaultColDef}
          rowSelection={'multiple'}
          pinnedTopRowData={[pinnedUnitData]}
          getRowStyle={getRowStyle}
          components={components}
        ></AgGridReact>
      )}
    </GridBox>
  );
});

export default AgGrid;
