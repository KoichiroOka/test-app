import { FC } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Container,
  Divider,
  Grid,
  Typography
} from '@mui/material';
import { styled } from '@mui/material/styles';

const TypographyH1 = styled(Typography)(
  ({ theme }) => `
    font-size: ${theme.typography.pxToRem(50)};
`
);

const TypographyH2 = styled(Typography)(
  ({ theme }) => `
    font-size: ${theme.typography.pxToRem(17)};
`
);

const LabelWrapper = styled(Box)(
  ({ theme }) => `
    background-color: ${theme.colors.success.main};
    color: ${theme.palette.success.contrastText};
    font-weight: bold;
    border-radius: 30px;
    text-transform: uppercase;
    display: inline-block;
    font-size: ${theme.typography.pxToRem(11)};
    padding: ${theme.spacing(0.5)} ${theme.spacing(1.5)};
    margin-bottom: ${theme.spacing(2)};
`
);

const Hero: FC = () => {
  return (
    <Container maxWidth="lg" sx={{ textAlign: 'center' }}>
      <Grid
        spacing={{ xs: 6, md: 10 }}
        justifyContent="center"
        alignItems="center"
        container
      >
        <Grid item md={10} lg={8} mx="auto">
          <LabelWrapper color="success">Version 0.1.0</LabelWrapper>
          <TypographyH1 sx={{ mb: 2 }} variant="h1">
            共有DB
          </TypographyH1>
          <TypographyH2
            sx={{ lineHeight: 1.5, pb: 4 }}
            variant="h4"
            color="text.secondary"
            fontWeight="normal"
          >
            Various Basic Data Base
          </TypographyH2>
        </Grid>
      </Grid>
      <Grid
        spacing={{ xs: 6, md: 10 }}
        justifyContent="center"
        alignItems="center"
        container
      >
        <Grid item md={10} lg={8} mx="auto">
          <Grid item xs={12} sx={{ margin: 1 }}>
            <Card>
              <CardHeader title="閲覧・検索" />
              <Divider />
              <CardContent>
                <Button
                  sx={{ margin: 1 }}
                  component={RouterLink}
                  to="/dashboards/frame"
                  size="large"
                  variant="contained"
                >
                  車体系
                </Button>
                <Button
                  sx={{ margin: 1 }}
                  component={RouterLink}
                  to="/dashboards/engine"
                  size="large"
                  variant="contained"
                  color="info"
                >
                  ENG系
                </Button>
                <Button
                  sx={{ margin: 1 }}
                  component={RouterLink}
                  to="/dashboards/research"
                  size="large"
                  variant="contained"
                  color="success"
                >
                  研究系
                </Button>
                <Button
                  sx={{ margin: 1 }}
                  component={RouterLink}
                  to="/dashboards/others"
                  size="large"
                  variant="contained"
                  color="secondary"
                >
                  他社
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sx={{ margin: 1 }}>
            <Card>
              <CardHeader title="その他" />
              <Divider />
              <CardContent>
                <Button
                  sx={{ margin: 1 }}
                  component={RouterLink}
                  to="/others"
                  size="large"
                  variant="outlined"
                  color="secondary"
                >
                  ユーザの声
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Hero;
