import { FC } from 'react';
import { Box, Container, Link, Typography, styled } from '@mui/material';

const FooterWrapper = styled(Container)(
  ({ theme }) => `
        margin-top: ${theme.spacing(0.5)};
`
);

const Footer: FC = () => {
  return (
    <FooterWrapper className="footer-wrapper">
      <Box
        pb={0.5}
        display={{ xs: 'block', md: 'flex' }}
        alignItems="center"
        textAlign={{ xs: 'center', md: 'left' }}
        justifyContent="space-between"
      >
        <Box>
          <Typography variant="subtitle1">&copy; 2022 - 共有DB</Typography>
        </Box>
        <Typography
          sx={{
            pt: { xs: 1, md: 0 }
          }}
          variant="subtitle1"
        >
          Ref :{' '}
          <Link href="http://172.28.34.145:183/" target="_blank">
            ENG_UI
          </Link>
        </Typography>
      </Box>
    </FooterWrapper>
  );
};

export default Footer;
