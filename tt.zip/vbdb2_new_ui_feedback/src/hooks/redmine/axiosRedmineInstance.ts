import axios, { AxiosInstance } from 'axios';

const BASE_URL = 'http://hga-redsvn01pz:81/redmine';
const API_KEY = '3b352811736ad29309aabcfb2705a339657e6c61';

const axiosRedmineInstance: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  params: {
    key: API_KEY
  },
  timeout: 300000
});

export default axiosRedmineInstance;
