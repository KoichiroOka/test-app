import axios, { AxiosInstance } from 'axios';
import { useCookies } from 'react-cookie';

const TEST_BASE_URL = 'http://hga-redsvn01pz:81/redmine';
const BASE_URL = 'http://hga-redsvn01pz/redmine';
const API_KEY = '3b352811736ad29309aabcfb2705a339657e6c61';

export const useAxiosRedmineInstance = () => {
  const [cookies] = useCookies();

  const axiosRedmineInstance: AxiosInstance = axios.create({
    baseURL: cookies['ENV'] === undefined ? TEST_BASE_URL : BASE_URL,
    params: {
      key: API_KEY
    },
    timeout: 300000
  });

  return axiosRedmineInstance;
};
