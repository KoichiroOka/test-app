import { useCallback, useState } from 'react';
import { useAxiosRedmineInstance } from './useAxiosRedmineInstance';

export const useApiPostAttachments = () => {
  const [token, setToken] = useState<string>('');

  const axiosRedmineInstance = useAxiosRedmineInstance();

  const getFileToken = useCallback(async (contentBuffer: ArrayBuffer) => {
    try {
      const response = await axiosRedmineInstance.post(
        '/uploads.json',
        contentBuffer,
        { headers: { 'Content-type': 'application/octet-stream' } }
      );
      setToken(response.data.upload.token);
    } catch (error) {
      console.error(error);
    }
  }, []);

  const uploadFile = useCallback(
    async (file: File) => {
      console.log('Post Attachments:', file);
      const contentBuffer: ArrayBuffer = await file.arrayBuffer();
      await getFileToken(contentBuffer);
    },
    [getFileToken]
  );

  return {
    uploadFile,
    token
  };
};
