import { useCallback, useState } from 'react';
import { PostIssue } from 'src/types/api/redmine/issue';
import { FeedbackForm } from 'src/types/FeedbackForm';
import { useApiListIssues } from './useApiListIssues';
import { useAxiosRedmineInstance } from './useAxiosRedmineInstance';

const PROJECT_ID = '642';

function today(): string {
  const today = new Date();
  const dd = String(today.getDate()).padStart(2, '0');
  const mm = String(today.getMonth() + 1).padStart(2, '0');
  const yyyy = today.getFullYear();
  const todayDate = `${yyyy}-${mm}-${dd}`;
  return todayDate;
}

export const useApiPostIssues = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const axiosRedmineInstance = useAxiosRedmineInstance();
  const { getFeedbackForms } = useApiListIssues();

  const postFeedbackForms = useCallback(
    async (props: FeedbackForm, token: string): Promise<void> => {
      console.log('Post Issues: ', props);

      const requestBody = {
        issue: {
          project_id: PROJECT_ID,
          subject: props.subject,
          tracker_id: props.tracker ? parseInt(props.tracker) : 1,
          description: props.description,
          start_date: today(),
          custom_fields: [{ id: 34, value: props.userId }],
          uploads: [{ token: token, filename: props?.postFileData?.name }]
        }
      };

      setLoading(true);

      axiosRedmineInstance
        .post<PostIssue>('/issues.json', requestBody)
        .then(async () => {
          getFeedbackForms();
        })
        .catch((error) => {
          console.log(error);
        })
        .finally(() => setLoading(false));
    },
    [getFeedbackForms]
  );

  return {
    postFeedbackForms,
    loading
  };
};
