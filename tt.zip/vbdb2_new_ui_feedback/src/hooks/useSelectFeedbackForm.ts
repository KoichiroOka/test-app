import { useCallback, useState } from 'react';
import { FeedbackForm } from 'src/types/FeedbackForm';

type Props = {
  id: number;
  feedbackForms: FeedbackForm[];
  handleOpen: () => void;
};

export const useSelectFeedbackForm = () => {
  const [selectedFeedbackForm, setSelectedFeedbackForm] =
    useState<FeedbackForm>();

  const onSelectFeedbackForm = useCallback((props: Props) => {
    const { id, feedbackForms, handleOpen } = props;
    const targetFeedbackForm = feedbackForms.find((obj) => obj.id === id);
    if (!targetFeedbackForm) {
      return;
    } else {
      setSelectedFeedbackForm(targetFeedbackForm);
      handleOpen();
    }
  }, []);
  return { onSelectFeedbackForm, selectedFeedbackForm };
};
