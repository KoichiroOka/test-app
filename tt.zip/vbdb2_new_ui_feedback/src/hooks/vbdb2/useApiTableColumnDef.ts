import { ColDef, ColGroupDef } from 'ag-grid-community';
import { useCallback } from 'react';
import { useTargetTable } from 'src/contexts/DataGridProvider';
import { TableColumn, TableColumnGroup } from 'src/types/api/tableColumn';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';

type ApiColumnDef = TableColumn | TableColumnGroup;

export const useApiTableColumnDef = () => {
  const { setAgColumnDef } = useTargetTable();
  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const mapColumnDefs = (columnDef: ApiColumnDef) => {
    if ('column_id' in columnDef) {
      return {
        headerName: columnDef.name,
        field: columnDef.column_id,
        hide: columnDef.hidden
      };
    } else {
      return {
        headerName: columnDef.name,
        groupId: columnDef.group_id,
        children: columnDef.children.map(mapColumnDefs).filter(Boolean)
      };
    }
  };

  const getAgColumnDef = useCallback((tableId: string) => {
    console.log('List Column-Definitions: ', tableId);
    axiosVbdb2Instance
      .get<ApiColumnDef[]>(`/tables/${tableId}/columnDefs`)
      .then(async (res) => {
        const agColumnDef: (ColDef | ColGroupDef)[] = res.data
          .map(mapColumnDefs)
          .filter(Boolean);
        setAgColumnDef(agColumnDef);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);
  return {
    getAgColumnDef
  };
};
