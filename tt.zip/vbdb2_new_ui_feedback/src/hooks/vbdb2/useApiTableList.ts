import { useCallback, useState } from 'react';
import { Table } from 'src/types/api/table';
import { TableTree } from 'src/types/TableTree';
import { AxiosInstance } from 'axios';
import { useAxiosVbdb2Instance } from './useAxiosVbdb2Instance';

const getTableTree = (tableProps: Table) => {
  const tableId = tableProps.table_id;
  const tableName = tableProps.name;
  const isDataGrid = tableProps.type === 'T';

  const children = tableProps.children?.map(getTableTree);

  return { id: tableId, name: tableName, isDataGrid, children };
};

const getTableList = async (
  groupId: 'E' | 'F' | 'A' | 'C',
  axiosVbdb2Instance: AxiosInstance
) => {
  try {
    const res = await axiosVbdb2Instance.get<Table[]>(`/groups/${groupId}`);
    const data: TableTree = {
      groupId,
      data: res.data.map(getTableTree)
    };
    return data;
  } catch (error) {
    console.log(error);
    throw error;
  }
};

export const useApiTableList = () => {
  const [gridList, setGridList] = useState<TableTree>({ groupId: 'F' });
  const [loading, setLoading] = useState(false);

  const axiosVbdb2Instance = useAxiosVbdb2Instance();

  const getGridList = useCallback(async (groupId: 'E' | 'F' | 'A' | 'C') => {
    console.log('List Group-Items: ', groupId);
    setLoading(true);
    try {
      const data = await getTableList(groupId, axiosVbdb2Instance);
      setGridList(data);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false);
    }
  }, []);

  return { getGridList, gridList, loading };
};
