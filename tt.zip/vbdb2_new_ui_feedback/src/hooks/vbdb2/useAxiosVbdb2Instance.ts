import axios, { AxiosInstance } from 'axios';
import useCookies from 'react-cookie/cjs/useCookies';

const BASE_URL =
  'http://hgaap02t.a.rd.honda.co.jp:7041/vbdb2-webservice/api/v2';
const USER_ID = 'J0134484';

export const useAxiosVbdb2Instance = () => {
  const [cookies] = useCookies();

  const axiosVbdb2Instance: AxiosInstance = axios.create({
    baseURL: BASE_URL,
    params: {
      user_id: cookies['ENV'] === undefined ? USER_ID : cookies['USER_ID']
    }
  });

  return axiosVbdb2Instance;
};
