import { useCallback, useState } from 'react';
import { ColumnTree } from 'src/types/ColumnTree';
import { useTargetTable } from 'src/contexts/DataGridProvider';

export const useColDefConverter = () => {
  const { agColumnDef, setAgColumnDef } = useTargetTable();
  const [selected, setSelected] = useState<string[]>([]);
  const [columnTree, setColumnTree] = useState<ColumnTree>({
    name: '全選択',
    id: '0-0',
    children: []
  });

  const pullColumnTree = useCallback(() => {
    const showData: string[] = [];

    const isLeafHidden = (props) =>
      'children' in props ? props.children.every(isLeafHidden) : props.hide;
    const isBranchHidden = (props) =>
      'children' in props ? props.children.every(isLeafHidden) : false;

    if (agColumnDef.every(isBranchHidden)) {
      showData.push('0-0');
    }

    const mapColumnDefs = (props) => {
      const isLeafHidden = (p) =>
        'children' in p ? p.children.every(isLeafHidden) : p.hide;
      const isBranchHidden = (p) =>
        'children' in p ? p.children.every(isLeafHidden) : false;

      if ('children' in props) {
        if (props.children.every(isBranchHidden)) {
          showData.push(props.groupId);
        }

        return {
          name: props.headerName,
          id: props.groupId,
          children: props.children.map(mapColumnDefs)
        };
      } else {
        if (!props.hide) {
          showData.push(props.field);
        }

        return {
          name: props.headerName,
          id: props.field
        };
      }
    };

    setColumnTree({
      name: '全選択',
      id: '0-0',
      children: agColumnDef.map(mapColumnDefs)
    });

    setSelected(showData);
  }, []);

  const putColumnTree = useCallback(
    (array: string[]) => {
      const mapColumnDefs = (props) => {
        if ('children' in props) {
          return {
            headerName: props?.headerName,
            groupId: props.groupId,
            children: props.children.map(mapColumnDefs)
          };
        } else {
          return {
            headerName: props?.headerName,
            field: props?.field,
            hide: !array.some((p) => p === props.field)
          };
        }
      };

      const colDefs = agColumnDef.map(mapColumnDefs);
      setAgColumnDef(colDefs);
    },
    [selected]
  );

  return {
    selected,
    setSelected,
    columnTree,
    setColumnTree,
    pullColumnTree,
    putColumnTree
  };
};
