export interface ColumnTree {
  id: string;
  name: string;
  hide?: boolean;
  children?: ColumnTree[];
}
