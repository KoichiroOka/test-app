export type Issue = {
  id?: number; //get
  tracker?: { id: number; name: string }; //get, post(1=不具合, 2=要望、3=その他)
  status?: { id: number; name: string }; //get
  subject?: string; //get, post
  description?: string; //get, post
  start_date?: string; //get, post
  custom_fields?: { id: number; value: string }[]; //post id=34
  project_id?: string;
  attachments: { filename: string }[];
};

export type ListIssues = {
  issues: Issue[];
};

export type PostIssue = {
  issue: {
    tracker_id?: number; //get, post(1=不具合, 2=要望、3=その他)
    subject?: string;
    description?: string;
    start_date?: string;
    custom_fields?: { id: number; name: string }; //post id=34
    project_id?: string;
    uploads?: { token?: string; filename?: string };
  };
};
