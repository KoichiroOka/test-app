export interface TableTree {
  groupId: 'E' | 'F' | 'A' | 'C';
  data?: GridList[];
}

export interface GridList {
  id?: string;
  name: string;
  isDataGrid: boolean;
  children?: GridList[];
}
