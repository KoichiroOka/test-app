export type FeedbackForm = {
  id?: number; //get
  userId?: string;
  tracker?: string; //get, post(1=不具合, 2=要望、3=その他)
  status?: string; //get(1=新規, 2=進行中、5=終了)
  subject?: string; //get, post
  description?: string; //get, post
  startDate?: string; //get, post
  getFileName?: string; //post
  postFileData?: File;
};
