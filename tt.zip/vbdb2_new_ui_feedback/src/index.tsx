import ReactDOM from 'react-dom';
import { HelmetProvider } from 'react-helmet-async';

import 'nprogress/nprogress.css';
import App from 'src/App';
import { SidebarProvider } from 'src/contexts/SidebarContext';
import { CookiesProvider } from 'react-cookie';

ReactDOM.render(
  <HelmetProvider>
    <CookiesProvider>
      <SidebarProvider>
        <App />
      </SidebarProvider>
    </CookiesProvider>
  </HelmetProvider>,
  document.getElementById('root')
);
