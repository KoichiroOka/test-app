import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useState
} from 'react';

import { FeedbackForm } from 'src/types/FeedbackForm';

type FeedbackContextType = {
  feedbackForms: FeedbackForm[] | null;
  setFeedbackForms: Dispatch<SetStateAction<FeedbackForm[] | null>>;
};

type Props = {
  children: ReactNode;
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const FeedbackContext = createContext<FeedbackContextType>(
  {} as FeedbackContextType
);

export const FeedbackProvider = (props: Props) => {
  const { children } = props;
  const [feedbackForms, setFeedbackForms] = useState<FeedbackForm[] | null>([]);

  return (
    <FeedbackContext.Provider
      value={{ feedbackForms: feedbackForms, setFeedbackForms }}
    >
      {children}
    </FeedbackContext.Provider>
  );
};

export const useFeedback = (): FeedbackContextType =>
  useContext(FeedbackContext);
