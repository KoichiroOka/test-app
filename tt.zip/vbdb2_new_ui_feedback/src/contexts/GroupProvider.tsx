import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useState
} from 'react';

type GroupContextType = {
  groupId: 'E' | 'F' | 'A' | 'C';
  groupMobileOpen: boolean | null;
  setGroupMobileOpen: Dispatch<SetStateAction<boolean | null>>;
};

type Props = {
  children: ReactNode;
  groupId: 'E' | 'F' | 'A' | 'C';
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const GroupContext = createContext<GroupContextType>({} as GroupContextType);

export const GroupProvider = (props: Props) => {
  const { children, groupId } = props;
  const [groupMobileOpen, setGroupMobileOpen] = useState<boolean | null>(false);

  return (
    <GroupContext.Provider
      value={{ groupId, groupMobileOpen, setGroupMobileOpen }}
    >
      {children}
    </GroupContext.Provider>
  );
};

export const useGroup = (): GroupContextType => useContext(GroupContext);
