import {
  createContext,
  Dispatch,
  ReactNode,
  SetStateAction,
  useContext,
  useEffect,
  useState
} from 'react';
import { ColDef, ColGroupDef } from 'ag-grid-community';

import { Table } from 'src/types/api/table';
import { useGroup } from './GroupProvider';

type TableContextType = {
  targetTable: Table | null;
  agColumnDef: (ColDef | ColGroupDef)[];
  pinnedUnitData: any;
  setTargetTable: Dispatch<SetStateAction<Table | null>>;
  setAgColumnDef: Dispatch<SetStateAction<(ColDef | ColGroupDef)[]>>;
  setPinnedUnitData: Dispatch<SetStateAction<any>>;
};

// eslint-disable-next-line @typescript-eslint/no-redeclare
const TargetTableContext = createContext<TableContextType>(
  {} as TableContextType
);

type Props = {
  children: ReactNode;
  groupId: string;
};

export const DataGridProvider = (props: Props) => {
  const { children } = props;
  const { groupId, groupMobileOpen, setGroupMobileOpen } = useGroup();
  useEffect(() => {
    setGroupMobileOpen(!groupMobileOpen);
  }, [groupId]);

  const [targetTable, setTargetTable] = useState<Table | null>({
    table_id: '',
    name: '',
    type: 'T',
    table_type: ''
  });

  const [agColumnDef, setAgColumnDef] = useState<(ColDef | ColGroupDef)[]>([]);

  const [pinnedUnitData, setPinnedUnitData] = useState<any>();

  return (
    <TargetTableContext.Provider
      value={{
        targetTable,
        agColumnDef,
        pinnedUnitData,
        setTargetTable,
        setAgColumnDef,
        setPinnedUnitData
      }}
    >
      {children}
    </TargetTableContext.Provider>
  );
};

export const useTargetTable = (): TableContextType =>
  useContext(TargetTableContext);
